from .critic import AICritic

__all__ = ["AICritic"]
